# ESP8266AnalogMux
Multiplexer extending ESP8266 resources to 8 Analog Inputs

Sketch for ESP8266 that reads 8 analog inputs. This sketch requires 74HC4051 multiplexer chip configured per http://wp.me/p5NRQ8-8y
